"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const image_viewer_component_1 = require("./src/image-viewer.component");
exports.ImageViewer = image_viewer_component_1.default;
exports.default = image_viewer_component_1.default;
//# sourceMappingURL=index.js.map