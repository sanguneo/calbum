import AutoGrowingTextInput from './src/AutoGrowingTextInput';

export {AutoGrowingTextInput};
