"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const image_zoom_component_1 = require("./image-zoom/image-zoom.component");
exports.ImageZoom = image_zoom_component_1.default;
exports.default = image_zoom_component_1.default;
//# sourceMappingURL=index.js.map