module.exports = require('./deprecated/indexDeprecated');
