package com.reactnativenavigation.utils;

public interface Task<T> {
    void run(T param);
}
