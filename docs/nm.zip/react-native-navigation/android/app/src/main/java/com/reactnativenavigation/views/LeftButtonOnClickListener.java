package com.reactnativenavigation.views;

public interface LeftButtonOnClickListener {
    boolean onTitleBarBackButtonClick();

    void onSideMenuButtonClick();
}
