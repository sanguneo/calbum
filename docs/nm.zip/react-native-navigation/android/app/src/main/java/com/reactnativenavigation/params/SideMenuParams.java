package com.reactnativenavigation.params;

import com.reactnativenavigation.views.SideMenu;

public class SideMenuParams extends BaseScreenParams {
    public boolean disableOpenGesture;
    public SideMenu.Side side;
}
