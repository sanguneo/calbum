
export const MMDRAWER_DOOR = 'door';
export const MMDRAWER_PARALLAX = 'parallax';
export const MMDRAWER_SLIDE = 'slide';
export const MMDRAWER_SLIDE_AND_SCALE = 'slide-and-scale';

export const THE_SIDEBAR_AIRBNB = 'airbnb';
export const THE_SIDEBAR_FACEBOOK = 'facebook';
export const THE_SIDEBAR_LUVOCRACY = 'luvocracy';
export const THE_SIDEBAR_WUNDER_LIST = 'wunder-list';
