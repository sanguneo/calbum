#import <React/RCTBridge.h>

@interface ImageResizer : NSObject <RCTBridgeModule>

@end
