"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    container: {
        justifyContent: 'center',
        alignItems: 'center',
        overflow: 'hidden',
        backgroundColor: 'transparent',
    }
};
//# sourceMappingURL=image-zoom.style.js.map