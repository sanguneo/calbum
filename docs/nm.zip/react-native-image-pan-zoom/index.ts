import ImageZoom from './image-zoom/image-zoom.component'
import {PropsDefine as ImageZoomPropsDefine} from './image-zoom/image-zoom.type'

export {ImageZoom, ImageZoomPropsDefine}
export default ImageZoom
                